# PROJECT REPORT
# Intelligent Channel Quality Prediction

## Abstract
Intelligent Channel Quality Prediction is a lightweight machine-learning web application designed to estimate the quality of a wireless communication channel from measurable network conditions. The system accepts Signal-to-Noise Ratio (SNR), Received Signal Strength Indicator (RSSI), interference level, latency and available bandwidth as inputs. A Random Forest regression model converts these parameters into a normalized channel-quality score from 0 to 100 and classifies the result as EXCELLENT, FAIR or POOR. A recommendation module then suggests simple corrective actions when weak channel conditions are detected.

The prototype is deliberately non-complex. It generates a synthetic training dataset at startup, trains the model locally, and presents the prediction through a futuristic Streamlit interface. This makes the project easy to demonstrate, modify and deploy without a database, specialized radio hardware or paid API.

## Chapter One — Introduction

### 1.1 Background
Wireless communication quality changes continuously because of distance, obstacles, noise, interference, congestion and traffic conditions. A communication system therefore needs useful indicators that describe whether a channel is healthy enough for reliable data transmission.

Traditional monitoring often presents individual measurements such as signal strength or latency. Looking at one measurement alone can be misleading. A strong signal can still experience high interference, while a moderate signal can perform well when the noise floor is low. Intelligent Channel Quality Prediction combines several measurements and applies machine learning to produce one easy-to-understand quality estimate.

### 1.2 Statement of the Problem
Wireless network operators and users may find it difficult to interpret multiple channel measurements at the same time. Manual analysis can delay detection of poor conditions and may not provide a clear overall channel-health indicator. A small intelligent prediction system is therefore useful for combining common channel measurements into an understandable quality score and recommending possible corrective actions.

### 1.3 Aim
The aim is to design and implement a simple intelligent system that predicts wireless channel quality from selected communication parameters using machine learning.

### 1.4 Objectives
1. Identify important input parameters affecting channel quality.
2. Generate a representative dataset for a classroom prototype.
3. Train a lightweight machine-learning regression model.
4. Predict a normalized channel-quality score from 0 to 100.
5. Classify the predicted channel as excellent, fair or poor.
6. Provide simple recommendations based on detected weak parameters.
7. Build an intuitive futuristic web interface.
8. Package the application for straightforward cloud deployment.

### 1.5 Significance
The project demonstrates how artificial intelligence can support communication-network monitoring. It is useful for students learning machine learning, wireless communications, Python programming and web-based data applications. It can also serve as a foundation for a future system connected to real routers, software-defined radios or network-monitoring sensors.

### 1.6 Scope
The prototype covers:
- SNR
- RSSI
- interference level
- latency
- available bandwidth
- machine-learning prediction
- quality classification
- recommendation generation
- interactive web visualization

The project does not implement physical radio control, automatic frequency switching, large-scale network management, authentication, multi-user databases or real-time telecom infrastructure.

### 1.7 Limitations
1. The training data is synthetic rather than collected from a live wireless network.
2. The model is intended for demonstration and academic purposes.
3. The five selected features do not represent every factor affecting channel quality.
4. Prediction accuracy on a real network would require field data and proper validation.
5. No physical communication hardware is controlled by the application.

## Chapter Two — Conceptual and Theoretical Framework

### 2.1 Channel Quality
Channel quality describes how suitable a communication medium is for reliable transmission. Good quality normally corresponds to adequate signal level, favorable signal-to-noise conditions, low interference, acceptable latency and sufficient capacity.

### 2.2 Signal-to-Noise Ratio
SNR compares desired signal power with noise power. It is normally expressed in decibels. A higher SNR generally indicates that the receiver can distinguish the desired signal more easily from background noise.

### 2.3 RSSI
RSSI is an indicator of received signal strength. In typical wireless systems it is represented in dBm. Values closer to zero are stronger than more negative values. RSSI alone is not sufficient to determine quality because a strong signal may coexist with strong interference.

### 2.4 Interference
Interference is unwanted energy from other transmitters or sources that can reduce communication reliability. Lower interfering power relative to the desired signal is generally preferable.

### 2.5 Latency
Latency is the time taken for information to travel through the communication system. Excessive latency can reduce the responsiveness of applications such as voice, video conferencing and interactive services.

### 2.6 Bandwidth
Bandwidth represents the capacity available over a communication channel. Greater available bandwidth can support higher data throughput, although actual throughput also depends on modulation, coding, protocol overhead, signal quality and congestion.

### 2.7 Machine Learning
Machine learning allows a computer to learn relationships between input variables and a target value from examples. In this project, the model learns the relationship between five channel measurements and a synthetic quality score.

### 2.8 Random Forest Regression
Random Forest regression combines predictions from multiple decision trees. It is suitable for this prototype because it can model nonlinear relationships and interactions between features without requiring a complicated mathematical model.

## Chapter Three — System Analysis and Design

### 3.1 System Requirements

#### Hardware
- Any modern laptop or desktop computer
- Internet connection for cloud deployment
- Optional smartphone or tablet for accessing the deployed dashboard

#### Software
- Python 3.10–3.12 recommended
- Streamlit
- NumPy
- Pandas
- Scikit-learn
- Web browser
- Git/GitHub for cloud deployment

### 3.2 Functional Requirements
The system shall:
1. Accept channel measurements.
2. Process the measurements.
3. Generate a quality prediction.
4. Display a quality score.
5. Display a quality category.
6. Present recommendations.
7. Display the current input values.
8. Report basic model evaluation metrics.

### 3.3 Non-functional Requirements
- Simple interface
- Fast response
- Low computational requirements
- Easy installation
- Easy deployment
- Readable visual output
- No external database dependency

### 3.4 System Architecture

```text
+-------------------------+
| User / Network Operator |
+------------+------------+
             |
             v
+-------------------------+
| Streamlit User Interface|
| SNR, RSSI, interference |
| latency, bandwidth      |
+------------+------------+
             |
             v
+-------------------------+
| Input Feature Processor |
+------------+------------+
             |
             v
+-------------------------+
| Random Forest Regressor |
+------------+------------+
             |
             v
+-------------------------+
| Quality Score 0–100     |
| Excellent/Fair/Poor     |
+------------+------------+
             |
       +-----+------+
       |            |
       v            v
+-------------+ +----------------+
| Dashboard   | | Recommendations|
+-------------+ +----------------+
```

### 3.5 Data Flow
1. User enters or adjusts channel measurements.
2. The application stores the values in a Pandas DataFrame.
3. The trained Random Forest receives the five features.
4. The model estimates the channel-quality score.
5. The score is clipped to the 0–100 range.
6. A rule-based classifier maps the score to EXCELLENT, FAIR or POOR.
7. The recommendation engine examines individual measurements and suggests actions.

## Chapter Four — System Implementation

### 4.1 Development Approach
The application uses Python as the main programming language and Streamlit as the web interface framework. The machine-learning layer uses scikit-learn. The dataset is generated programmatically, which avoids dependency on an external data source.

### 4.2 Synthetic Dataset
The prototype generates 1,800 records. Each record contains:
- SNR: 0–35 dB
- RSSI: -110 to -40 dBm
- interference: -105 to -45 dBm
- latency: 5–180 ms
- bandwidth: 1–100 MHz

A controlled mathematical relationship plus random noise is used to create the quality target. This is appropriate for demonstrating the complete machine-learning workflow, but it must not be interpreted as a field-calibrated telecom dataset.

### 4.3 Model Training
The data is divided into training and test subsets using an 80:20 split. A Random Forest Regressor with 140 trees and a maximum depth of 9 is trained. Mean Absolute Error (MAE) and R² are calculated on the held-out test set.

### 4.4 Prediction
The prediction is converted into a percentage-like score:

`Quality Score = clip(Model Prediction, 0, 100)`

Classification:
- 75–100: EXCELLENT
- 50–74.99: FAIR
- 0–49.99: POOR

### 4.5 Recommendation Logic
The recommendation layer checks practical thresholds. For example:
- Low SNR → improve signal conditions.
- Weak RSSI → reduce distance/obstacles or review antenna placement.
- High interference → consider another channel/frequency.
- High latency → inspect congestion or routing.
- Low bandwidth → reduce load or increase capacity.

### 4.6 User Interface
The interface uses:
- Dark futuristic background
- Rounded information cards
- Minimal navigation
- Sidebar input controls
- Large prediction indicators
- Bar visualization of signal characteristics
- Recommendation cards
- Expandable model information

## Chapter Five — Testing and Results

### 5.1 Unit/Functional Tests
| Test | Input condition | Expected result |
|---|---|---|
| Normal channel | Good SNR/RSSI, low interference, low latency | Higher quality score |
| Weak signal | Low RSSI and SNR | Lower quality and signal recommendation |
| Interference | High interference | Lower quality and interference recommendation |
| Congestion | High latency | Lower quality and latency recommendation |
| Low capacity | Low bandwidth | Lower quality and capacity recommendation |

### 5.2 Model Evaluation
The dashboard reports MAE and R² after training. Because the data is synthetic and generated from a known relationship, these values are intended to demonstrate the evaluation process rather than establish real-world telecom performance.

### 5.3 Expected Result
For favorable input conditions, the dashboard should produce a relatively high quality score and an EXCELLENT or FAIR state. When multiple adverse conditions are introduced, the score should fall and the recommendation panel should identify the relevant weaknesses.

## Chapter Six — Advantages and Applications

### 6.1 Advantages
- Simple implementation
- Low computational cost
- Interactive interface
- No external database
- Easy to demonstrate
- Easy to extend with real data
- Combines several channel parameters into one indicator

### 6.2 Potential Applications
- Wireless network monitoring
- Academic laboratory demonstrations
- Wi-Fi optimization studies
- IoT communication monitoring
- Research prototypes
- Network troubleshooting dashboards

## Chapter Seven — Conclusion and Future Work

### 7.1 Conclusion
The Intelligent Channel Quality Prediction project demonstrates a complete machine-learning workflow in a compact web application. It accepts communication parameters, processes them through a Random Forest model, produces a quality score and provides human-readable recommendations. The architecture is intentionally simple so it can be understood, demonstrated and deployed by a student.

### 7.2 Future Improvements
1. Replace synthetic data with measurements from real Wi-Fi or cellular networks.
2. Add throughput, packet loss, jitter and channel utilization.
3. Compare Random Forest with XGBoost, neural networks and linear models.
4. Store historical measurements for trend analysis.
5. Add real-time monitoring from routers or software-defined radios.
6. Add user authentication and role-based access.
7. Introduce automatic channel-selection recommendations.
8. Deploy the model as a separate API for larger systems.
9. Continuously retrain the model using validated field measurements.

## References / Suggested Reading
- Scikit-learn documentation — machine learning algorithms and model evaluation.
- Streamlit documentation — Python web application development and deployment.
- General wireless communication/networking textbooks covering SNR, RSSI, interference, latency and bandwidth.
